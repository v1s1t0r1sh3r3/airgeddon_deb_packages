# -*- coding: binary -*-
# Sets the path appropriately when examples is adjacent to the real lib.

$:.unshift(File.expand_path(File.dirname(__FILE__) + "/../lib/"))
