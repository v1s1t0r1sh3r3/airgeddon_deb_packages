# frozen_string_literal: true

module Net
  module DNS
    # The current library version.
    VERSION = "0.9.1".freeze
  end
end
