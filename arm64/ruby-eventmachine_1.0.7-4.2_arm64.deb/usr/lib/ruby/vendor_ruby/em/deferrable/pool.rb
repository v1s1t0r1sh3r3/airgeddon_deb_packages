warn "EM::Deferrable::Pool is deprecated, please use EM::Pool"
EM::Deferrable::Pool = EM::Pool