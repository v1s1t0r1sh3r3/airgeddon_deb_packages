./hashcat -m 500 example500.hash example.dict
